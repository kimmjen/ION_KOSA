ACCEPT A_NUM PROMPT '���� �Է�?'
DECLARE

	NUM NUMBER := &A_NUM;
BEGIN

	DBMS_OUTPUT.PUT_LINE('NUM : ' || NUM  || ',&A_NUM : ' || &A_NUM);
END;
/
      