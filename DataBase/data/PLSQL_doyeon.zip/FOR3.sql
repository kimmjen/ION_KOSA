BEGIN
	/*
	2 * 1 = 2  3 * 1 =3......9*1 =9 
	2 * 2 = 4  3 * 2 =6......9*2 =18
	...        ..       .....
	2 * 9 =18  3 * 9 =27     9*9 =81

	*/
	FOR K IN 1..9 LOOP
		FOR J IN 2..9 LOOP
			DBMS_OUTPUT.PUT(J || ' * ' || K || ' = ' || K*J || '  ');
		END LOOP;
		DBMS_OUTPUT.NEW_LINE;
	END LOOP;

END;
/