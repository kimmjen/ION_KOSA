/*  문제4] 자료형에 맞춰서 선언하고 값 출력하는 프로그램 작성
   이름 String 
   나이 int
   키 또는 몸무게 실수형
*/
package day03_basic.Quiz;

public class Q_5 {
	public static void main(String[] args) {
		String name = "김제민";
		int age = 30;
		double height = 171;
		double weight = 86;
		
		System.out.println("이름: " + name);
		System.out.println("나이: " + age);
		System.out.println("키: " + height);
		System.out.println("몸무게: " + weight);

	}
}
